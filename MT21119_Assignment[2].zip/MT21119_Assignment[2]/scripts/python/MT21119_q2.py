import os
import shutil
import cv2
from fcmeans import FCM
import numpy as np

def get_patches(start,end,patch_size):
    patches = []
    while start < end:
        patch = (start, start+patch_size)
        patches.append(patch)
        start = start+patch_size
    return patches

def lbp(image, center_x, center_y):
    central_pixel = image[center_x][center_y]
    x = [-1, -1, -1, 0, 1, 1, 1, 0]
    y = [-1, 0, 1, 1, 1, 0, -1, -1]
    powers = [1, 2, 4, 8, 16, 32, 64, 128]
    thresholds = []
    length = 8
    for i in range(length):
        try:
            neighbour_pixel = image[center_x + x[i]][center_y + y[i]]
            val = round(min(central_pixel, neighbour_pixel) / max(central_pixel, neighbour_pixel)) 
            #LBP modification: Assign 1 or 0 in your LBP codes depending on the value of
            #round(min(N,C)/max(N,C)), where N is the neighboring pixel and C is the central pixel.
            thresholds.append(val * powers[i])
        except IndexError as e:
            thresholds.append(0)
        except ValueError as e:
            thresholds.append(0)
    return sum(thresholds)

def histogram_calculate(image):
    rows, columns = np.shape(image)
    lbp_values = []
    for i in range(rows):
        for j in range(columns):
            lbp_values.append(lbp(image, i, j))
    hist, _ = np.histogram(lbp_values, bins=256)
    return hist

images = []
features = []
column_names = ["feature_{}".format(i) for i in range(1,5377)]
count = 1
for file in os.listdir('C:/Users/Drishya/Downloads/dd'):
    #print("Image..{}, count = {}".format(file, count))
    count = count + 1
    feature = []
    img = cv2.imread('C:/Users/Drishya/Downloads/dd/{}'.format(file))
    img = cv2.resize(img, (224, 224))
    img = cv2.cvtColor(img, cv2.COLOR_BGR2GRAY)
    images.append(file)
    patch_sizes = [224, 112, 56]
    for size in patch_sizes:
        patch = get_patches(0, 224, size)
        for start in patch:
            for end in patch:
                # print("Start = {}, end = {}".format(start, end))
                histogram = histogram_calculate(img[start[0]:start[1], end[0]:end[1]])
                # print(histogram)
                feature.extend(histogram.flatten())
                # print("Feature Vector Size = {}".format(len(feature)))
    features.append(feature)

data = np.array(features)
print(np.shape(data))

clusters = int(input('Input clusters'))
model = FCM(n_clusters=clusters)
model.fit(data)

centers = model.centers
labels = model.predict(data)

print(centers)
print(labels)

if os.path.exists('Output'):
    shutil.rmtree('Output')

os.mkdir('Output')

unique_labels = np.unique(labels)
for label in unique_labels:
    os.mkdir('Output/Cluster_{}'.format(label+1))

for index in range(len(labels)):
    label = labels[index]
    file = images[index]
    src = 'C:/Users/Drishya/Downloads/dd/{}'.format(file)
    dest = 'Output/Cluster_{}'.format(label+1)
    shutil.copy(src, dest)



