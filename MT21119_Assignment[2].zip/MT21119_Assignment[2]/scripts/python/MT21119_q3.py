import numpy as np
import matplotlib.pyplot as plt
from os import listdir
from imageio import imread
from sklearn.feature_extraction.image import extract_patches_2d
from sklearn.decomposition import PCA
from sklearn.cluster import KMeans
from joblib import Parallel, delayed
import imageio
imgq = imageio.imread(path_query)
from skimage import feature
import skimage.io, skimage.color
import numpy
import matplotlib.pyplot

def patch_extract(img_file, random_state, patch_size=(11, 11), n_patches=250):
    img = imread(img_file)
    
    # Extract subimages
    patch = extract_patches_2d(img, 
                               patch_size=patch_size,
                               max_patches=n_patches, 
                               random_state=random_state)
    
    return patch.reshape((n_patches, 
                          np.prod(patch_size) * len(img.shape)))


tam_patch = (15, 15)
n_patches = 250
path_imgs = 'C:/Users/Drishya/Downloads/dd/'
random_state = 1

# get list of files
l_imgs = listdir(path_imgs)
# total of images
n_imgs = len(l_imgs)

# Extract patches in parallel
# returns a list of the same size of the number of images
patch_arr = Parallel(n_jobs=-1)(delayed(patch_extract)(path_imgs+arq_img, 
                                                    random_state,
                                                    tam_patch,
                                                    n_patches)
                                for arq_img in l_imgs)

print('Patches extracted to create dictionary of features')
print('Total of images = ', len(patch_arr))
print('Size of each array of patches = ', patch_arr[0].shape)

# shows some image patches
img_ind = 32
plt.figure(figsize=(8,3))
for i in np.arange(1,11):
    plt.subplot(2,5,i)
    plt.imshow(patch_arr[img_ind][i].reshape((tam_patch[0],tam_patch[1],3)))
    plt.axis('off')


# ---
# ### Step 2 - obtain features from patches
# 
# We are going to use HOG features as base descriptor

# In[2]:


def gradient_calculation(img, template):
    ts = template.size #Number of elements in the template (3).
    #New padded array to hold the resultant gradient image.
    new_img = numpy.zeros((img.shape[0]+ts-1, 
                           img.shape[1]+ts-1))
    new_img[numpy.uint16((ts-1)/2.0):img.shape[0]+numpy.uint16((ts-1)/2.0), 
            numpy.uint16((ts-1)/2.0):img.shape[1]+numpy.uint16((ts-1)/2.0)] = img
    result = numpy.zeros((new_img.shape))
    
    for r in numpy.uint16(numpy.arange((ts-1)/2.0, img.shape[0]+(ts-1)/2.0)):
        for c in numpy.uint16(numpy.arange((ts-1)/2.0, 
                              img.shape[1]+(ts-1)/2.0)):
            curr_region = new_img[r-numpy.uint16((ts-1)/2.0):r+numpy.uint16((ts-1)/2.0)+1, 
                                  c-numpy.uint16((ts-1)/2.0):c+numpy.uint16((ts-1)/2.0)+1]
            curr_result = curr_region * template
            score = numpy.sum(curr_result)
            result[r, c] = score
    #Result of the same size as the original image after removing the padding.
    result_img = result[numpy.uint16((ts-1)/2.0):result.shape[0]-numpy.uint16((ts-1)/2.0), 
                        numpy.uint16((ts-1)/2.0):result.shape[1]-numpy.uint16((ts-1)/2.0)]
    return result_img

def magnitude_calculation(horizontal_gradient, vertical_gradient):
    horizontal_gradient_square = numpy.power(horizontal_gradient, 2)
    vertical_gradient_square = numpy.power(vertical_gradient, 2)
    sum_squares = horizontal_gradient_square + vertical_gradient_square
    grad_magnitude = numpy.sqrt(sum_squares)
    return grad_magnitude

def direction_calculation(horizontal_gradient, vertical_gradient):
    grad_direction = numpy.arctan(vertical_gradient/(horizontal_gradient+0.00000001))
    grad_direction = numpy.rad2deg(grad_direction)
    grad_direction = grad_direction%180
    return grad_direction

def HOG_histogram(cell_direction, cell_magnitude, hist_bins):
    HOG_cell_hist = numpy.zeros(shape=(hist_bins.size))
    cell_size = cell_direction.shape[0]
    
    for row_idx in range(cell_size):
        for col_idx in range(cell_size):
            curr_direction = cell_direction[row_idx, col_idx]
            curr_magnitude = cell_magnitude[row_idx, col_idx]
    
            diff = numpy.abs(curr_direction - hist_bins)
            
            if curr_direction < hist_bins[0]:
                first_bin_idx = 0
                second_bin_idx = hist_bins.size-1
            elif curr_direction > hist_bins[-1]:
                first_bin_idx = hist_bins.size-1
                second_bin_idx = 0
            else:
                first_bin_idx = numpy.where(diff == numpy.min(diff))[0][0]
                temp = hist_bins[[(first_bin_idx-1)%hist_bins.size, (first_bin_idx+1)%hist_bins.size]]
                temp2 = numpy.abs(curr_direction - temp)
                res = numpy.where(temp2 == numpy.min(temp2))[0][0]
                if res == 0 and first_bin_idx != 0:
                    second_bin_idx = first_bin_idx-1
                else:
                    second_bin_idx = first_bin_idx+1
            
            first_bin_value = hist_bins[first_bin_idx]
            second_bin_value = hist_bins[second_bin_idx]
            HOG_cell_hist[first_bin_idx] = HOG_cell_hist[first_bin_idx] + (numpy.abs(curr_direction - first_bin_value)/(180.0/hist_bins.size)) * curr_magnitude
            HOG_cell_hist[second_bin_idx] = HOG_cell_hist[second_bin_idx] + (numpy.abs(curr_direction - second_bin_value)/(180.0/hist_bins.size)) * curr_magnitude
    return HOG_cell_hist



patch_arr = np.array(patch_arr, copy=True)
patch_arr = patch_arr.reshape((patch_arr.shape[0] * patch_arr.shape[1],
                              tam_patch[0],tam_patch[0],3))

# obtaining features hog for each patch
patch_hog = []
for pat in patch_arr:
        #f = lbp_features(pat,2,8)  
        pat = skimage.color.rgb2gray(pat) 
        horizontal_mask = numpy.array([-1, 0, 1])
        vertical_mask = numpy.array([[-1],
                             [0],
                             [1]])

        horizontal_gradient = gradient_calculation(pat, horizontal_mask)
        vertical_gradient = gradient_calculation(pat, vertical_mask)

        grad_magnitude = magnitude_calculation(horizontal_gradient, vertical_gradient)
        grad_direction = direction_calculation(horizontal_gradient, vertical_gradient)

        grad_direction = grad_direction % 180
        hist_bins = numpy.array([10,30,50,70,90,110,130,150,170])

        # Histogram of the first cell in the first block.
        cell_direction = grad_direction[:8, :8]
        cell_magnitude = grad_magnitude[:8, :8]
        HOG_cell_hist = HOG_histogram(cell_direction, cell_magnitude, hist_bins)
        patch_hog.append(HOG_cell_hist)

patch_hog = np.array(patch_hog, copy=False)
print('Instances = ', len(patch_hog), ' size = ', patch_hog[0].shape[0])
print('Created HOG feature spaces')
print('\tpatches = ', len(patch_hog), ' size = ', patch_hog[0].shape[0])

n_dic = 50 # size of the dictionary
random_state = 1

# Define a KMeans clustering model
kmeans_model = KMeans(n_clusters=n_dic, 
                      verbose=False, 
                      init='random',
                      random_state=random_state, 
                      n_init=3)
# fit the model
kmeans_model.fit(patch_hog)

# compute features for each image
img_feats = []
for i in range(n_imgs):
    # predicting n_patches of an image
    y = kmeans_model.predict(patch_hog[i*n_patches: (i*n_patches)+n_patches])

    # computes histogram and append in the array
    hist_bof,_ = np.histogram(y, bins=range(n_dic+1), density=True)
    img_feats.append(hist_bof)
    print(img_feats)

img_feats = np.array(img_feats, copy=False)
print('Number of images and features = ', img_feats.shape)

# query
path_query = 'C:/Users/Drishya/Downloads/dd/15_11_s.jpg'
# get query patches
query_patches = patch_extract(path_query, random_state, tam_patch, n_patches)
query_patches = np.array(query_patches, copy=False)

query_patches = query_patches.reshape((query_patches.shape[0],
                               tam_patch[0],tam_patch[0],3))

print('Extracted patches')
print(query_patches.shape)

# get HOG feathres
query_hog = []
for pat in query_patches:
        #f = lbp_features(pat,2,8)
        pat = skimage.color.rgb2gray(pat) 
        horizontal_mask = numpy.array([-1, 0, 1])
        vertical_mask = numpy.array([[-1],
                             [0],
                             [1]])

        horizontal_gradient = gradient_calculation(pat, horizontal_mask)
        vertical_gradient = gradient_calculation(pat, vertical_mask)

        grad_magnitude = magnitude_calculation(horizontal_gradient, vertical_gradient)
        grad_direction = direction_calculation(horizontal_gradient, vertical_gradient)

        grad_direction = grad_direction % 180
        hist_bins = numpy.array([10,30,50,70,90,110,130,150,170])

        # Histogram of the first cell in the first block.
        cell_direction = grad_direction[:8, :8]
        cell_magnitude = grad_magnitude[:8, :8]
        HOG_cell_hist = HOG_histogram(cell_direction, cell_magnitude, hist_bins)
        query_hog.append(HOG_cell_hist)

query_hog = np.array(query_hog, copy=False)
print('HOG extractd')
print(query_hog.shape)

# get visual words for query
y = kmeans_model.predict(query_hog)
# computes descriptor
query_feats,_ = np.histogram(y, bins=range(n_dic+1), density=True)

# computes distances
dists = []
for i in range(n_imgs):
    diq = np.sqrt(np.sum((img_feats[i]-query_feats)**2))
    dists.append(diq)

# check the nearest images
k = 8
k_cbir = np.argsort(dists)[:k]

plt.figure(figsize=(12,8))
plt.subplot(331); plt.imshow(imgq)
plt.title('Query'); plt.axis('off')

imgs = []
for i in range(k):
    imgs.append(imageio.imread(path_imgs+l_imgs[k_cbir[i]]))
    plt.subplot(3,3,i+2); plt.imshow(imgs[i])
    plt.title('%d, %.4f' % (i, dists[k_cbir[i]])); plt.axis('off')




