import torch
import torchvision
import  torchvision.transforms as transforms
import numpy as np
import matplotlib.pyplot as plt
from PIL import Image
import os
from os import path
import numpy as np
import cv2
#pretrained resnet model
model = torchvision.models.resnet50(pretrained=True)
print(model)

#define transforms to preprocess input image into format expected by model
normalize = transforms.Normalize(mean=[0.485, 0.456, 0.406],std=[0.229, 0.224, 0.225])
#inverse transform to get normalize image back to original form for visualization
inverse = transforms.Normalize(mean=[-0.485/0.229, -0.456/0.224, -0.406/0.255],std=[1/0.229, 1/0.224, 1/0.255]
)

#transforms to resize image to the size expected by pretrained model,
#convert PIL image to tensor, and
#normalize the image
transform = transforms.Compose([
    transforms.Resize((224, 224)),
    transforms.ToTensor(),
    normalize,          
])

def saliency_dl(img, model):
    for param in model.parameters():
        param.requires_grad = False
    
    #evaluate model
    model.eval()
    #transform input image
    input = transform(img)
    input.unsqueeze_(0)
    input.requires_grad = True
    
    #forward pass 
    preds = model(input)
    score, indices = torch.max(preds, 1)
    #backward pass 
    print(score.backward())
    #get max along channel axis
    slc, _ = torch.max(torch.abs(input.grad[0]), dim=0)
    #normalize to [0..1]
    slc = (slc - slc.min())/(slc.max()-slc.min())

    #apply inverse transform on image
    with torch.no_grad():
        input_img = inverse(input[0])
    #plot image and its saleincy map
    plt.figure(figsize=(10, 10))
    plt.subplot(1, 2, 1)
    plt.imshow(np.transpose(input_img.detach().numpy(), (1, 2, 0)))
    plt.xticks([])
    plt.yticks([])
    plt.subplot(1, 2, 2)
    x=plt.imshow(slc.numpy(), cmap=plt.cm.hot)
    plt.xticks([])
    plt.yticks([])
    plt.show()
    
    
for file in os.listdir('C:/Users/Drishya/Downloads/dd/'):
    img = Image.open('C:/Users/Drishya/Downloads/dd/{}'.format(file)).convert('RGB')
    saliency_dl(img, model)

# <h2>Non DL based Saliency Map</h2>

def saliency_nondl(image):

    # Read in the image
    
    pixel_vals = image.reshape((-1, 3))
    pixel_vals = np.float32(pixel_vals)
    criteria = (cv2.TERM_CRITERIA_EPS + cv2.TERM_CRITERIA_MAX_ITER, 100, 0.85)
    k = 85
    retval, labels, centers = cv2.kmeans(pixel_vals, k, None, criteria, 10, cv2.KMEANS_RANDOM_CENTERS)
    # get the centers and convert them
    centers = np.uint8(centers)
    segmented_data = centers[labels.flatten()]
    #apply kmeans 
    kmeans_segmented_image = segmented_data.reshape((image.shape))
    cv2.imshow("Image", kmeans_segmented_image)
    cv2.waitKey(0)

    #calculate the distances(eucliedian)
    distances = []
    for i in range(len(centers)):
        temp = []
        for j in range(len(centers)):
            center1 = centers[i]
            center2 = centers[j]
            d = np.sqrt((center1[0] - center2[0]) ** 2 + (center1[1] - center2[1]) ** 2 + (center1[2] - center2[2]) ** 2)
            temp.append(d)
        distances.append(temp)

    unique, frequency = np.unique(labels, return_counts=True)
    total = sum(frequency)
    f = frequency / total

    saliency_values = []
    for i in range(len(centers)):
        s = 0
        for j in range(len(centers)):
            if i != j:
                s = s + f[j] * distances[i][j]
        saliency_values.append(s)

        #get the new centers after applying the above functions
    new_centers = []
    for i in range(len(centers)):
        sal_value = saliency_values[i]
        t = [sal_value, sal_value, sal_value]
        new_centers.append(t)

    new_centers = np.uint8(new_centers)
    new_segmented_data = new_centers[labels.flatten()]
    new_segmented_image = new_segmented_data.reshape((image.shape))

    final_image = cv2.cvtColor(new_segmented_image, cv2.COLOR_BGR2GRAY)

    cv2.imshow("Image", final_image)
    cv2.waitKey(0)
    
    
for file in os.listdir('C:/Users/Drishya/Downloads/dd/'):
    
    img = cv2.imread('C:/Users/Drishya/Downloads/dd/{}'.format(file))
    saliency(img)




