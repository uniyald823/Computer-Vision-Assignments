# import the necessary packages
from skimage.segmentation import slic
from skimage.segmentation import mark_boundaries
from skimage.util import img_as_float
from skimage import io
import matplotlib.pyplot as plt
import numpy as np
import math
#for checking images for different segment value
'''path = 'C:/Users/Drishya/OneDrive/Desktop/A3_Q2/0002.jpg'#give the path of the image
i = img_as_float(io.imread(path))#convert it to a floating point data type
for numSegments in (100, 1000, 5000, 10000):
	# apply SLIC and extract (approximately) the supplied number
	# of segments
    segments = slic(i, n_segments = numSegments, sigma = 5)
    #segments = slic(i, n_segments = 10000, sigma = 5)#sigma , which is the smoothing Gaussian kernel applied prior to segmentation.
    #To draw the actual superpixel segmentations, scikit-image provides us with a mark_boundaries function
    #plt.imshow(mark_boundaries(i, segments))# locally similar regions of the image are grouped
    fig = plt.figure("Superpixels -- %d segments" % (numSegments))
    ax = fig.add_subplot(1, 1, 1)
    ax.imshow(mark_boundaries(i, segments))
    plt.axis("off")
  '''  
    
path = 'C:/Users/Drishya/OneDrive/Desktop/A3_Q2/0002.jpg'#give the path of the image
i = img_as_float(io.imread(path))#convert it to a floating point data type
segments = slic(i, n_segments = 5000, sigma = 5)#sigma , which is the smoothing Gaussian kernel applied prior to segmentation.
   
# takes the highest segments
# segment contains the image on which we applied slic.
rows, columns = np.shape(segments)
new = np.reshape(segments, rows*columns) #reshape according to rows and columns
unique_labels = np.unique(new)
length = len(unique_labels)
    
R_superpixel = [0]*length
G_superpixel = [0]*length
B_superpixel = [0]*length
X_superpixel = [0]*length
Y_superpixel = [0]*length

#Our image is RGB so we have to take take of that and reshape accordingly.
R, G, B = i[:,:,0], i[:,:,1], i[:,:,2]

R = np.reshape(R, rows*columns)
G = np.reshape(G, rows*columns)
B = np.reshape(B, rows*columns)
    
for label in unique_labels:        
    R[np.where(new == label)] = np.mean(R[np.where(new == label)])
    G[np.where(new == label)] = np.mean(G[np.where(new == label)])
    B[np.where(new == label)] = np.mean(B[np.where(new == label)])
        
    # make arrays that contain unique superpixel RGB values.
    R_superpixel[label] = np.mean(R[np.where(new == label)])
    G_superpixel[label] = np.mean(G[np.where(new == label)])
    B_superpixel[label] = np.mean(B[np.where(new == label)])        
    X_superpixel[label] = np.mean(np.where(segments == label)[0])
    Y_superpixel[label] = np.mean(np.where(segments == label)[1])
    

    
#get the segmented image and reshape it accordingly to RGB
new_image = np.zeros(np.shape(i))
new_image[:,:,0] = np.reshape(R, (rows,columns))
new_image[:,:,1] = np.reshape(G, (rows,columns))
new_image[:,:,2] = np.reshape(B, (rows,columns))
    

#print(type(segmented_image[0,0,0]))
#get minimum and maximum of the segmented image
print(np.min(new_image))
print(np.max(new_image))
plt.title("Segmented Image")
plt.imshow(new_image)

#return segmented_image, new_array, super_pixel_R, super_pixel_G, super_pixel_B, super_pixel_X, super_pixel_Y

#define length for R's superpixel
length = len(R_superpixel)
saliency_values = [0]*length
#let height and width store the values of segmented image
height, width, _ = np.shape(new_image)
#perform calculations for eucliedian distance
height2_width2 = np.sqrt(width*width + height*height)

#loop through the length and compute the distances for RGB
#get the saliency values
for i in range(length):
    sal = 0
    for j in range(length):
        distance_of_colours = np.sqrt(((R_superpixel[i]-R_superpixel[j])**2) + ((G_superpixel[i]-G_superpixel[j])**2) + ((B_superpixel[i]-B_superpixel[j])**2))
        distance = np.sqrt(((X_superpixel[i]-X_superpixel[j])**2) + ((Y_superpixel[i]-Y_superpixel[j])**2))
        value = distance_of_colours * math.exp(-(distance/height2_width2))
        sal = sal + value # store the saliency values
    saliency_values[i] = sal
    
    
#now we perform below task for getting the saliency map for segmented image that we got after performing the above calculations
rows, columns, _ = np.shape(new_image)
unique_labels = np.unique(new)
R, G, B = new_image[:,:,0], new_image[:,:,1], new_image[:,:,2]

R = np.reshape(R, rows*columns)
G = np.reshape(G, rows*columns)
B = np.reshape(B, rows*columns)

for label in unique_labels:
    R[np.where(new == label)] = saliency_values[label]
    G[np.where(new == label)] = saliency_values[label]
    B[np.where(new == label)] = saliency_values[label]   

R *= (1.0/R.max())
G *= (1.0/G.max())
B *= (1.0/B.max())
    
resulted_image = np.zeros(np.shape(new_image))

resulted_image[:,:,0] = np.reshape(R, (rows,columns))
resulted_image[:,:,1] = np.reshape(G, (rows,columns))
resulted_image[:,:,2] = np.reshape(B, (rows,columns))

plt.title("Segmented Image")
io.imshow(resulted_image)
