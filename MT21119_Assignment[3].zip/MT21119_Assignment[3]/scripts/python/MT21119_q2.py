import sys
from PIL import Image
import sys
import math
from ast import literal_eval
from PIL import Image
import time

# Open and read img
image = ('C:/Users/Drishya/OneDrive/Desktop/A3_Q2/0002.jpg')
im = Image.open(image)
im = im.resize((128, 128)) # due to high compuattion time I have reduced the dimensions of the image and then checked.
pix = im.load()
xval, yval = im.size
Array = [] #conatins the values of image

# Map pixel values to array
for y in range(yval):
    Array.append([])
    for x in range(xval):
        Array[y].append(list(pix[x, y]))

print(Array)

# Distance functions
def ED(P, Q):
    intermediateValues = []
    for i in range(len(P[2])):
        intermediateValues.append(math.pow(Q[2][i] - P[2][i], 2))
    return math.sqrt(sum(intermediateValues))


# Finds all neighbor points for a chosen point
def Neighbors(Point, Points, distanceFunction, eps):
    tempNeighbours = []
    for y in range(len(Points)):
        for x in range(len(Points[0])):
            if distanceFunction == "e":
                if ED(Point, Points[y][x]) <= eps:
                    tempNeighbours.append(Points[y][x])

    return tempNeighbours

# Input the values
vectors = literal_eval(sys.stdin.read())
r = int(sys.argv[1])   #100,200,500
minPts = int(sys.argv[2])#100,200,500
distFunc = sys.argv[3]  #e

#if wrong value is given exit the system.
if distFunc != "e":
    sys.exit(1)

# prepare array
Array = []
for y in range(len(vectors)):
    Array.append([])
    for x in range(len(vectors[0])):
        Array[y].append([y, x, vectors[y][x], "Undefined"])

# DBSCAN ALgorithm
#check for neighbors and find the clusters
cluster = 0
progress = 0
for y in range(len(vectors)):
    for x in range(len(vectors[0])):
        if Array[y][x][-1] != "Undefined":
            continue

        Neighbours = Neighbors(Array[y][x],Array, distFunc, r)
        if len(Neighbours) < minPts:
            Array[y][x][-1] = "Noise"
            continue

        cluster = cluster+ 1
        Array[y][x][-1] = str(cluster)
        if Array[y][x] in Neighbours:
            Neighbours.remove(Array[y][x])

        for innerPoint in Neighbours:
            if innerPoint[-1] == "Noise":
                Array[innerPoint[0]][innerPoint[1]][-1] = str(cluster)
            if innerPoint[-1] != "Undefined":
                continue
            Array[innerPoint[0]][innerPoint[1]][-1] = str(cluster)
            NeighboursInner = Neighbors(innerPoint, Array, distFunc, r)
            if len(NeighboursInner) >= minPts:
                Neighbours.append(NeighboursInner)

# Get distinct clusters
number_of_clusters[]
for y in range(len(vectors)):
    for x in range(len(vectors[0])):
        if Array[y][x][-1] not in number_of_clusters:
            number_of_clusters.append(Array[y][x][-1])

# Map cluster's averages
averagesForClusters = []
for item in clusterNumbers:
    n = 0
    vectorTemps = [0] * len(Array[0][0][2])
    for y in range(len(vectors)):
        for x in range(len(vectors[0])):
            if Array[y][x][-1] == item:
                for i in range(len(Array[y][x][2])):
                    vectorTemps[i] = vectorTemps[i] + Array[y][x][2][i]
                n = n + 1
    # Check 0 division
    for i in range(len(vectorTemps)):
        if vectorTemps[i] != 0:
            vectorTemps[i] = vectorTemps[i] / n
    averagesForClusters.append(vectorTemps)

# Build clustered array 
clusteredVectors = []
for y in range(len(Array)):
    clusteredVectors.append([])
    for x in range(len(Array[0])):
        clusteredVectors[y].append(averagesForClusters[clusterNumbers.index(Array[y][x][-1])])

print(clusteredVectors)
