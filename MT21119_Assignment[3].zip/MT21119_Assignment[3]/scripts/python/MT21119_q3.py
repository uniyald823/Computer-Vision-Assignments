import cv2
import time
img = cv2.imread('0002.jpg',0)
start = time.process_time()
sift = cv2.xfeatures2d.SIFT_create()
keypoints_sift, descriptors = sift.detectAndCompute(img, None)
print("The time for SIFT is:",time.process_time() - start)  #seconds
#0.110836728
start1 = time.process_time()
surf = cv2.xfeatures2d.SURF_create()
keypoints_surf, descriptors = surf.detectAndCompute(img, None)
print("The time for SURF is:",time.process_time() - start1)  #seconds
#0.18647063399999997
