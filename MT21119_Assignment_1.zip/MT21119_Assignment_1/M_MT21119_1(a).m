rgb=imread("D:\semester2_mtech\computer_vision\Assignments\MT21119_Component_xxx\Data\Input\leaf.png");
subplot(1,2,1);
imshow(rgb);
redChannel=rgb(:, :, 1);
greenChannel=rgb(:, :, 2);
blueChannel=rgb(:, :, 3);
data=double([redChannel(:), greenChannel(:), blueChannel(:)]);
numberOfClasses= 85;
[a b]=kmeans(data,numberOfClasses);
a=reshape(a,size(rgb,1),size(rgb,2));
b=b/255;
clusteredImage=label2rgb(a,b);
subplot(1,2,2);
imshow(clusteredImage);

%% Implementing Equation 3 on leaf Image
I= clusteredImage;
[bincount,binloc]=hist(double(I(:,:,3)),256);
% plot(binloc,bincount)
a=sum(bincount.*binloc)/sum(bincount);
Ig=rgb2gray(I);
msk=I(:,:,3)<=a-10;
msk=bwareaopen(msk,250);
msk3=cat(3,msk,msk,msk);
Icrop=immultiply(I,msk3);
%imshowpair(I,Icrop,'montage')
BW4 = im2bw(Icrop);
BW5 = imfill(BW4,'holes');
figure, imshow(BW5)
imwrite(BW5,'D:\semester2_mtech\computer_vision\Assignments\MT21119_Component_xxx\ImagesOutput\result_equation_3.png')
