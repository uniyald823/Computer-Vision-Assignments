import numpy as np
from PIL import Image, ImageOps
import matplotlib.pyplot as plt  
import pandas as pd
gray = np.array(Image.open('D:/semester2_mtech/computer_vision/Assignments/MT21119_Component_xxx/Data/Input/horse (1).jpg').convert('L'))
print(type(gray))      
his, b = np.histogram(gray, np.array(range(0, 256)))
final_thresh = -1
final_value = -1    
print(his)

t_list = b    
for t in b[1:-1]:
    wb = np.sum(his[:t])
    wf = np.sum(his[t:])         
    #calculating Mean
    mub = np.mean(his[:t])
    muf = np.mean(his[t:])

    #calculating total sum of squares
    value = (mub - muf) ** 2
    if value > final_value:
        final_thresh = t
        final_value = value
    thres_list[t] =  final_thresh
        
final_image = gray.copy()
    
#final_thresh = 207- 57
print(final_thresh)
print("Threshold Values",t_list)
df = pd.DataFrame(thres_list)
# saving the threshold values
df.to_csv('D:/semester2_mtech/computer_vision/Assignments/MT21119_Component_xxx/Data/Output/Thresh.csv')
final_img[gray > final_thresh] = 255
final_img[gray < final_thresh] = 0    
plt.imshow(final_img,cmap='gray')   
# saving the Final Image
plt.savefig("D:/semester2_mtech/computer_vision/Assignments/MT21119_Component_xxx/ImagesOutput/result_q2.png")
plt.show()
